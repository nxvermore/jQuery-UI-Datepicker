<?php
/**
 * Plugin Name: jQuery UI Datepicker
 * Plugin URI: https://ultbit.com
 * Description: Integrates the jQuery UI datepicker library in WordPress
 * Version: 1.0
 * Author: Nxvermore
 * Author URI: https://ultbit.com
 */

function jquery_ui_datepicker_enqueue_scripts() {
    wp_enqueue_script( 'jquery-ui-datepicker' );
    wp_enqueue_style( 'jquery-ui-datepicker', 'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css' );
}
add_action( 'wp_enqueue_scripts', 'jquery_ui_datepicker_enqueue_scripts' );